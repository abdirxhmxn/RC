document.querySelector('#convert').addEventListener('click', convert)
let selectCel = document.querySelector('#celsius')
let selectFar = document.querySelector('#farenheit')

selectCel.addEventListener('change', cToF)
selectFar.addEventListener('change', fToC)

let initialDeg = document.querySelector('#temp').value
let newDeg

function cToF() {
    newDeg = (initialDeg * 1.8) + 32
    //add a console I clicked farenheit
    console.log('I clicked farenheit and will convert to celsius')
    console.log(selectCel)
}
function fToC() {
    newDeg = (initialDeg - 32) / 1.8
    console.log('I clicked celsius and will convert to farenheit')
    console.log(selectFar)
}
function convert() {
    //User input a number (float)
    
    if (initialDeg && selectCel) {
        document.querySelector('#print').innerText = `${initialDeg} farenheit converted to celsius is: ${newDeg}`
    } else if (initialDeg && selectFar) {
        farenheit();
        document.querySelector('#print').innerText = `${initialDeg} celsius converted to farenheit is: ${newDeg}`
    }
    console.log('Input a number and then select what unit it is before you convert it.')
    document.querySelector('#print').innerText = `Input a number and then select what unit it is before you convert it.${initialDeg} ${newDeg}`
}